// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'test_info.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TestInfo _$TestInfoFromJson(Map<String, dynamic> json) => TestInfo(
      age: json['age'] as int? ?? 0,
      name: json['name'] as String? ?? '',
    );

Map<String, dynamic> _$TestInfoToJson(TestInfo instance) => <String, dynamic>{
      'age': instance.age,
      'name': instance.name,
    };
