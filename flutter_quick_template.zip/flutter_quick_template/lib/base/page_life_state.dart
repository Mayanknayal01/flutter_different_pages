mixin PageLifeState {
  void onPageVisible() {}

  void onPageActive() {}

  void onPageInActive() {}

  void onPageInVisible() {}
}
