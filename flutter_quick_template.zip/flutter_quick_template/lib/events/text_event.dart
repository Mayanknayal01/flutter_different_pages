class CustomTextEvent {
  CustomTextEvent({required this.text});
  String text = "";
}
