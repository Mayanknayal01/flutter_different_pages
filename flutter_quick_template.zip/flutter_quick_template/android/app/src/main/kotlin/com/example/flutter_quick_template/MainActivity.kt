package com.example.flutter_quick_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
